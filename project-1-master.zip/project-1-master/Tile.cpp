#include "Tile.h"

void Tile::SetToken(char token) {
    this->token = token;
}

char Tile::GetToken() {
    //cout << token << " ";
    return token;
}

void Tile::UpdatePopulation() {
    this->population++;
}

int Tile::GetPopulation() {
    return population;
}

void Tile::SetPosition(int xPos, int yPos) {
    this->xPos = xPos;
    this->yPos = yPos;
}
int Tile::GetXPosition() {
    return xPos;
}
int Tile::GetYPosition() {
    return yPos;
}
