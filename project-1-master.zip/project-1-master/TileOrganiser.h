#ifndef TILEORGANISER_H
#define TILEORGANISER_H

#include "Tile.h"

class TileOrganiser {
    public:
        vector<vector<Tile>> TileOrganiserMain(vector<vector<char>> cityInput, int turns, int refresh);
        void FillCity(vector<Tile> &city, vector<vector<char>> cityInput);
        vector<vector<Tile>> ReturnCity2D(vector<Tile> cityCurrent);
        void PrintCity(vector<Tile> city, int xSize);
        bool TilesUpdate(vector<Tile> &city);
        void OrganiseByPosition(vector<Tile> &city);
        void UpdateWorkersAndGoods(int &numWorkers, int &futureWorkers, int &numGoods, int &futureGoods, Tile tile, bool updating);
        void OrganiseTiles(vector<Tile> &updateOrder, vector<Tile> city);
        vector<Tile> ReplaceVector(vector<vector<Tile>> &sortedList);
        bool IsTileAdjacent(Tile homeTile, Tile checkTile);
        void AdjacentPopulation(Tile tile, vector<Tile> city, int *population);
        bool PopulationCheck(Tile tile, vector<Tile> city);
};

#endif
