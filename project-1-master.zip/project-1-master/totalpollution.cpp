#include "totalpollution.h"

int totalPollution(std::vector<std::vector<int>> pollution,int oX, int oY, int x, int y){
    int total = 0;

    for(int i = oX; i<=x; i++){
        for(int j = oY; j<=y; j++){
            total+=pollution[i][j];
        }
    }

    return total;
}
