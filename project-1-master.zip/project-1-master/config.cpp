

#include "config.h"
#include <string>
#include <fstream>

// Constructors
config::config() { configFile = ""; regionFile = ""; timeLimit = 0; refreshRate = 0; };
config::config(std::string cf, std::string rf, int t, int r) {
	configFile = cf; regionFile = rf; timeLimit = t; refreshRate = r; };

// Setters
void config::SetConfigFile(std::string cf) { this->configFile = cf; };
void config::SetRegionFile(std::string rf) { this->regionFile = rf; };
void config::SetTimeLimit(int t) { this->timeLimit = t; };
void config::SetRefreshRate(int r) { this->refreshRate = r; };

// Getters
std::string config::GetConfigFile() { return configFile; };
std::string config::GetRegionFile() { return regionFile; };
int config::GetTimeLimit() { return timeLimit; };
int config::GetRefreshRate() { return refreshRate; };
