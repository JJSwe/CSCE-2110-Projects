# City Simulation Project
**Group 9: Allyson Tesky, Josh Sweeney, Ross Pulliam**

## Overview
This submission includes all needed files to meet all project 1 requirements. The application requires the user provide a configuration file. The file must contain the location of the region.csv file, the time limit of the simulation, and the refresh rate to display the simulation updates to the console. The configuration file is expected in the following format:<br/>

Region Layout:region.csv<br/>
Time Limit:20<br/>
Refresh Rate:1<br/>

The program will confirm the configuration file is in text format (.txt file extension) and the region file is a comma separated values file (.csv). If these requirements are not met the user will have opportunity to input a corrected filename.

Assuming a proper configuration file is provided, the simulation will run automatically and the appropriate number of simulation updates will be displayed to the console. When the simulation completes, the user will be given the option to display more detailed population and pollution data of a specified grid. This step can be skipped by inputting -1 as the grid location for any of the four points.

### Building and running the application:
    Use the included makefile to manage the compilation and run functions
        make:       rebuild the application
        make debug: build the application with debug flags
        make clean: remove the compiled object and executable files
        make run:   execute the program

### Sample user input
    Input the configuration file when prompted: config.txt
    The simulation will execute and provide console output per the configuration settings
    Provide grid coordinates when prompted to display more detailed population and pollution statistics for any rectangular area
        A rectangular grid will be formed from 2 cartesian coordinate pairs (X1,Y1) to (X2, Y2)
        This detailed view can be skipped by entering -1 for any single point in the coordinate pairs
    Program ends

### Sample execution
```
If the configuration file is located outside the program directory, please include the full path.
What is the name of the config file (filename.txt)? config.txt

Initial Region State
------------------
|    T # T T T   |
|I I I - C C T   |
|I I I - C C T P |
|I I I - C C T   |
|- - - - - - # - |
|    - R R R T   |
|    - R R R     |
|    - R R R     |
------------------

Time Step: 1
Available Workers 2 Available Goods 0
------------------
|    T # T T T   |
|I I I - C C T   |
|I I I - C C T P |
|I I I - C C T   |
|- - - - - - # - |
|    - R R 1 T   |
|    - R R 1     |
|    - R R R     |
------------------

Time Step: 2
Available Workers 4 Available Goods 1
------------------
|    T # T T T   |
|I 1 I - C C T   |
|I I I - C C T P |
|I I I - C C T   |
|- - - - - - # - |
|    - R 1 1 T   |
|    - R 1 1     |
|    - R 1 1     |
------------------

Time Step: 3
Available Workers 10 Available Goods 1
------------------
|    T # T T T   |
|1 1 I - 1 C T   |
|I I I - C C T P |
|I I I - C C T   |
|- - - - - - # - |
|    - 1 2 2 T   |
|    - 1 2 2     |
|    - 1 2 2     |
------------------


Final Region State
------------------
|    T # T T T   |
|1 1 I - 1 C T   |
|I I I - C C T P |
|I I I - C C T   |
|- - - - - - # - |
|    - 1 2 2 T   |
|    - 1 2 2     |
|    - 1 2 2     |
------------------


Pollution
------------------
|0 0 0 0 0 0 0 0 |
|1 1 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
|0 0 0 0 0 0 0 0 |
------------------
The total populations for the region are: 
Residential: 15
Industrial: 2
Commercial: 1
The total pollution in the region is 2 units
Please enter the diagonal corners of the area you wish to have more information about.
  (MinX = 0, MinY = 0, MaxX = 7, MaxY = 7)
  (enter a negative number to skip.
X1: 0
Y1: 0
X2: 7
Y2: 7
The total populations for the requested area are: 
Residential: 15
Industrial: 2
Commercial: 1
The total pollution in the requested area is 2 units
```
