#ifndef TOTALPOLLUTION_H
#define TOTALPOLLUTION_H
#include <iostream>
#include <vector>

int totalPollution(std::vector<std::vector<int>>, int, int,int,int);

#endif
