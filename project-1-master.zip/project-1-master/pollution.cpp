#include "pollution.h"

vector<vector<int>>Pollution(vector<vector<Tile>>city){
vector<vector<int>> pollution;
int maxSpread = 0;

// Creates a pollution vector out of Industrial zone populations
for (int i = 0; i < city.size(); i++){
    pollution.push_back(vector<int>());
    for (int j = 0; j < city[0].size(); j++){
        if(city[i][j].GetToken()=='I'){
            pollution[i].push_back(city[i][j].GetPopulation());
            if (city[i][j].GetPopulation()>maxSpread){
                maxSpread = city[i][j].GetPopulation();
            }
        }
        else{
            pollution[i].push_back(0); // Sets pollution to 0 if not industrial
        }
    }
}

// Simulates pollution spread
for (int n = 0; n < (maxSpread-1); n++){
    for(int x = 0; x<pollution.size(); x++){
        for(int y = 0; y<pollution[0].size();y++){
            for(int i = -1; i<2; i++){ //i and j allow updating of adjacent cells
                for(int j = -1; j<2; j++){
                    if((x+i)>=0&&(x+i)<pollution.size()&&(y+j)>=0&&(y+j)<pollution[0].size()){ // Ensures adjacency is within bounds
                        if(pollution[x+i][y+j]<(pollution[x][y]-1)){
                            pollution[x+i][y+j]=(pollution[x][y]-1);
                        }
                    }
                }
            }
        }
    }

}

// Print Total Pollution
// Top Border
cout << "Pollution\n";
for(int i = 0; i < ((pollution.size()*2)+2); i++){
    cout << "-";
}
cout << "\n|";
for(int x = 0; x<pollution.size();x++){
    if(x>0&&x%pollution.size()&&x!=pollution.size()){
        cout << "|\n|"; // Side Borders
    }
    for(int y = 0; y<pollution[0].size();y++){
        cout << pollution[x][y] << " ";
    }

}
cout << "|\n";
// Bottom Border
for(int i = 0; i < ((pollution.size()*2)+2); i++){
    cout << "-";
}
cout << endl;

return pollution;
}
