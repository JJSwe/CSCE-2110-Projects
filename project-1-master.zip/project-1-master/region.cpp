
#include <vector>
#include <fstream>
#include <iostream>
#include "region.h"
#include "config.h"

// constructors
region::region() { cityDef.clear(); };
region::region(std::vector<std::vector<char>> c) { cityDef = c; } ;

// Utilities
void region::Fileio(config *c) { 
	// Open File
	std::ifstream file;
	std::string line;
	std::vector<char> cityLine;

	file.open(c->GetRegionFile()); // Open region file from config file object
	if (file.is_open()) {
		getline(file, line);
		while (!file.eof()) {
			for (int i = 0; i < line.length(); i++)
				if (line[i] != ',') {
					cityLine.push_back(line[i]); // build inner vector of each line of data from region csv
				}
			cityDef.push_back(cityLine); // Add inner vector to 2d vector, one line of csv data at a time
			cityLine.clear(); // clear line vector to prepare for next line
			getline(file, line);
		}
	}
	else
		std::cout << "Failed to open region file: " << c->GetRegionFile() << std::endl;
};

std::vector<std::vector<char>> region::GetCity() { return cityDef; };
