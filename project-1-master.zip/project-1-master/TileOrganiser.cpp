#include <iostream>
#include <string>
#include <vector>
#include <math.h>
using namespace std;
#include "Tile.h"
#include "TileOrganiser.h"

enum tokens {Residential = 'R', Industrial = 'I', Commercial = 'C', Road = '-', 
    Powerline = 'T', RoadAndPowerline = '#', Powerplant = 'P'}; //All known city zones
const int MAX_POPULATION = 5; //Used to make population arrays

//Calls all other functions. Has the update and print loop.
vector<vector<Tile>> TileOrganiser::TileOrganiserMain(vector<vector<char>> cityInput, int turns, int refresh) {
    vector<Tile> city;
    FillCity(city, cityInput);

    cout << "Initial Region State" << endl;
    PrintCity(city, cityInput[0].size());
    for(int loop = 0; loop < turns; loop++) {//Loop that updates & prints the city.
        cout << "Time Step: " << loop + 1 << endl;
        bool futureGrowth = TilesUpdate(city);//Updates tiles.
        if(loop % refresh == 0) {
            PrintCity(city, cityInput[0].size());//Prints city.
        } else {
            cout << endl;
        }
        if(!futureGrowth) {//Ends loop if there's no possible future growth.
            break;
        }
    }
    cout << endl << "Final Region State" << endl;
    PrintCity(city, cityInput[0].size());

    OrganiseByPosition(city);
    return ReturnCity2D(city);
}

//Turns the city input into city tiles. Creates the tile & sets the token & position.
void TileOrganiser::FillCity(vector<Tile> &city, vector<vector<char>> cityInput) {
    Tile tile;
    for (int y = 0; y < cityInput.size(); y++) {
        for (int x = 0; x < cityInput[0].size(); x++) {
            city.push_back(tile);
            city.back().SetToken(cityInput[y][x]);//Gets 'x' tile in 'y' array.
            city.back().SetPosition(x, y);
        }
    }
}

//Turns a 1d tile vector into a 2d tile vector.
vector<vector<Tile>> TileOrganiser::ReturnCity2D(vector<Tile> cityCurrent) {
	vector<vector<Tile>> cityReturn;
    int yPos = -1;
    int cityCurrentPos = 0;

    while(!cityCurrent.empty()) {
        if(cityCurrent.front().GetXPosition() == 0) {
            cityReturn.push_back(vector<Tile>());
            yPos++;
        }
        cityReturn[yPos].push_back(cityCurrent.front());
        cityCurrent.erase(cityCurrent.begin());
    }
    return cityReturn;
}

//Prints out the city.
void TileOrganiser::PrintCity(vector<Tile> city, int xSize) {
    OrganiseByPosition(city);
    for(int loop = 0; loop < xSize * 2 + 2; loop++) {
        cout << '-';//Top border
    }
    cout << endl << "|";
    while(!city.empty()) {
        Tile tile = city.front();
        city.erase(city.begin());
        char token = '0' + tile.GetPopulation();
        if(token == '0') {//Prints pop, unless pop is zero.
            token = tile.GetToken();
        }
        if(tile.GetXPosition() == 0 && tile.GetYPosition() != 0) {
            cout << "|" << endl << "|";//Side border
        }
        cout << token << " ";//Prints token
    }
    cout << "|" << endl;
    for(int loop = 0; loop < xSize * 2 + 2; loop++) {
        cout << '-';//Bottom border
    }
    cout << endl << endl;
}

//Sorts tiles based on their x and y position.
void TileOrganiser::OrganiseByPosition(vector<Tile> &city) {
    vector<Tile> citySorted;
    int xTracker = 0;
    int yTracker = 0;
    int xMax = 0;
    for(Tile tile : city) {//Finds largest possible x-position of tiles.
        if(tile.GetXPosition() > xMax) {
            xMax = tile.GetXPosition();
        }
    }
    while(!city.empty()) {//Adds tile to citySorted if it has the next x & y position.
        for(int pos = 0; pos < city.size(); pos++) {
            if(city[pos].GetXPosition() == xTracker && city[pos].GetYPosition() == yTracker) {
                citySorted.push_back(city[pos]);
                city.erase(city.begin() + pos);
                break;
            }
        }
        xTracker++;
        if(xTracker > xMax) {//Moves to next y-pos if all tiles in curr x-pos are gathered.
            xTracker = 0;
            yTracker++;
        }
    }
    city = citySorted;
}

//Orders and updates the tiles while keeping track of the city's resources. Returns false if no more room to grow.
bool TileOrganiser::TilesUpdate(vector<Tile> &city) {
    vector<Tile> updatedTiles;
    vector<Tile> tilesToSort;
    int numWorkers = 0, numGoods = 0, futureWorkers = 0, futureGoods = 0;
    for (Tile tile : city) {//Updates residential, keeps track of workers & goods, and makes tilesToSort.
        char token = tile.GetToken();

        if(token == Residential) {
            UpdateWorkersAndGoods(numWorkers, futureWorkers, numGoods, futureGoods, tile, false);
            if(PopulationCheck(tile, city)) {
                tile.UpdatePopulation();
                futureWorkers++;
            }
            updatedTiles.push_back(tile);
        } else if(token == Commercial) {
            UpdateWorkersAndGoods(numWorkers, futureWorkers, numGoods, futureGoods, tile, false);
            tilesToSort.push_back(tile);
        } else if(token == Industrial) {
            UpdateWorkersAndGoods(numWorkers, futureWorkers, numGoods, futureGoods, tile, false);
            tilesToSort.push_back(tile);
        } else {
            updatedTiles.push_back(tile);
        }
    }
    if(tilesToSort.size() > 0) {//Sorts & updates tilesToSort and keeps track of workers & goods.
        OrganiseTiles(tilesToSort, city);
        for (Tile tile : tilesToSort) {
            char token = tile.GetToken();
            int pop = tile.GetPopulation();
            if(token == Commercial && pop < 2 && numWorkers >= 1 && numGoods >= 1) {//Max size is 2, needs 1 worker & 1 good.
                if(PopulationCheck(tile, city)) {
                    UpdateWorkersAndGoods(numWorkers, futureWorkers, numGoods, futureGoods, tile, true);
                    tile.UpdatePopulation();
                }
            } else if(token == Industrial && pop < 3 && numWorkers >= 2) {//Max size is 3, needs 2 workers.
                if(PopulationCheck(tile, city)) {
                    UpdateWorkersAndGoods(numWorkers, futureWorkers, numGoods, futureGoods, tile, true);
                    tile.UpdatePopulation();
                }
            }
            updatedTiles.push_back(tile);//Adds tiles, updated or not, to city.
        }
    }
    city = updatedTiles;
    cout << "Available Workers " << futureWorkers << " Available Goods " << futureGoods << endl;
    return futureWorkers;//If no more future workers or goods, return false.
}

//Updates the count for workers, goods, future workers & future goods.
void TileOrganiser::UpdateWorkersAndGoods(int &numWorkers, int &futureWorkers, int &numGoods, int &futureGoods, Tile tile, bool updating) {
    char token = tile.GetToken();
    int pop = tile.GetPopulation();

    if(token == Residential) {//Residential zones make 1 worker per population.
        numWorkers += pop;
        futureWorkers += pop;
    } else if(token == Commercial) {//Industrial zones use 1 good and 1 worker per population.
        if(updating) {
            numWorkers--;
            futureWorkers--;
            numGoods--;
            futureGoods--;
        } else {
            numWorkers -= pop;
            futureWorkers -= pop;
            numGoods -= pop;
            futureGoods -= pop;
        }   
    } else if(token == Industrial) {//Industrial zones make 1 good and use 2 workers per population.
        if(updating) {
            numWorkers -= 2;//Industrial tiles need 2 workers per population.
            futureWorkers -= 2;
            futureGoods++;
        } else {
            numWorkers -= pop * 2;//Industrial tiles need 2 workers per population.
            futureWorkers -= pop * 2;
            numGoods += pop;
            futureGoods += pop;
        }
    }
}

//Organises the tiles based on 5 rules given in the project description.
void TileOrganiser::OrganiseTiles(vector<Tile> &updateOrder, vector<Tile> city) {
    vector<vector<Tile>> popAdjacentList (MAX_POPULATION * 8 + 1);//max pop * max possible neighbors
    vector<vector<Tile>> popList (MAX_POPULATION + 1);
    vector<vector<Tile>> zoneList (2);

    OrganiseByPosition(updateOrder);//Position sorter.
    for(Tile tile : updateOrder) {//Adjacent population sorter.
        int popAdjacent = 0;
        int populationArray[MAX_POPULATION + 1];
        AdjacentPopulation(tile, city, populationArray);
        for(int loop = 1; loop <= MAX_POPULATION; loop++) {//Loop must start at 1 to not count powerlines.
            popAdjacent += populationArray[loop] * loop;
        }
        popAdjacentList[popAdjacent].push_back(tile);
    }
    updateOrder = ReplaceVector(popAdjacentList);
    for(Tile tile : updateOrder) {//Population sorter.
        popList[tile.GetPopulation()].push_back(tile);
    }
    updateOrder = ReplaceVector(popList);
    for(Tile tile : updateOrder) {//Zone sorter.
        int zoneType = 0;
        if(tile.GetToken() == Commercial) {
            zoneType = 1;
        }
        zoneList[zoneType].push_back(tile);
    }
    updateOrder = ReplaceVector(zoneList);
}

//Turns a 2d sorted vector into a 1d sorted vector.
vector<Tile> TileOrganiser::ReplaceVector(vector<vector<Tile>> &sortedList) {
    vector<Tile> newList;
    for(int loop = sortedList.size() - 1; loop >= 0; loop--) {
        while(!sortedList[loop].empty()) {
            newList.push_back(sortedList[loop].front());//Adds to 1d vect from 2d vect
            sortedList[loop].erase(sortedList[loop].begin());//Deletes from 2d vect
        }
    }
    return newList;

}

//Returns true if tile is adjacent, false if tile is not adjacent or is the tile being checked.
bool TileOrganiser::IsTileAdjacent(Tile homeTile, Tile checkTile) {
    int xPos = abs(homeTile.GetXPosition() - checkTile.GetXPosition());
    int yPos = abs(homeTile.GetYPosition() - checkTile.GetYPosition());
    if(xPos <= 1 && yPos <= 1 && (xPos + yPos) != 0) {//Math for checking that tile is adjacent
        return true;
    } else {
        return false;
    }
}

//Figures out the population in adjacent tiles.
void TileOrganiser::AdjacentPopulation(Tile tile, vector<Tile> city, int *population) {
    for(int loop = 0; loop <= MAX_POPULATION; loop++) {
        population[loop] = 0;
    }
    for (Tile cityTile : city) {
        if (IsTileAdjacent(tile, cityTile)) {
            if(cityTile.GetPopulation() > 0) {
                population[cityTile.GetPopulation()]++;//Adjacent and populated tiles are recorded.
            } else if((cityTile.GetToken() == Powerline || cityTile.GetToken() == RoadAndPowerline)) {
                population[0]++;//Powerlines allow zones with 0 pop to grow.
            }
        }
    }
}

//Checks if tiles can grow based on surrounding population.
bool TileOrganiser::PopulationCheck(Tile tile, vector<Tile> city) {
    int tilePop = tile.GetPopulation();
    int population[MAX_POPULATION + 1];
    int popAdjacent = 0;
    int popGoal = tilePop * 2;
    if(popGoal == 0) {//Tiles with pop of 0 need 1 adj tile of 1 pop to grow, or powerline.
        popGoal = 1;
    }
    AdjacentPopulation(tile, city, population);
    for(int loop = tilePop; loop <= MAX_POPULATION; loop++) {
        popAdjacent += population[loop];//Finds number of adjacent tiles with needed pop.
    }
    if(popAdjacent >= popGoal) {
        return true;
    } else {
        return false;
    }
}