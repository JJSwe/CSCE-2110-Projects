#ifndef POPULATION_H
#define POPULATION_H
#include "TileOrganiser.h"

void population(vector<vector<Tile>>,int,int,int,int);

#endif
