#include "population.h"

void population(vector<vector<Tile>> city,int oX, int oY, int x,int y){
int residential = 0, industrial = 0, commercial = 0;

    for(int i = oX; i<=x; i++){ // Using x and y instead of vector size allows printing for smaller areas
        for(int j = oY; j<=y; j++){
            if(city[i][j].GetPopulation()>0){ // checks for population first to avoid unnecessary checks
                if(city[i][j].GetToken()=='R'){
                    residential+=city[i][j].GetPopulation();
                }
                else if(city[i][j].GetToken()=='I'){
                    industrial+=city[i][j].GetPopulation();
                }
                else if(city[i][j].GetToken()=='C'){
                    commercial+=city[i][j].GetPopulation();
                }
            }
        }
    }

    cout << "Residential: "<< residential <<
    endl << "Industrial: " << industrial <<
    endl << "Commercial: " << commercial << endl;

}
