
#ifndef REGION_H
#define REGION_H

#include <string>
#include <vector>
#include <fstream>
#include "config.h"

class region {
	public:
		// default constructor
		region();

		// parameterized constructor
		region(std::vector<std::vector<char>> c);

		// Utilities
		void Fileio(config *c);
		std::vector<std::vector<char>> GetCity();

	private:
		std::vector<std::vector<char>> cityDef;

};

#endif
