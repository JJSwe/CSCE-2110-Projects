
#ifndef TILE_H
#define TILE_H

#include <iostream>
#include <vector>
using namespace std;

//Stores data for each tile of the city
class Tile {
    public:
        void SetToken(char token);
        char GetToken();
        void UpdatePopulation();
        int GetPopulation();
        void SetPosition(int xPos, int yPos);
        int GetXPosition();
        int GetYPosition();

    private:
        char token = ' ';
        int population = 0;
        int xPos = -1;
        int yPos = -1;
};

#endif
