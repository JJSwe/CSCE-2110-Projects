/*****************************************************************************/
/* File: main.cpp                                                            */
/* Authors: Allyson Tesky, Josh Sweeney, Ross Pulliam                        */
/* Creation Date: 29 JUN 2021                                                */
/*****************************************************************************/
/* Revisions:                                                                */
/* Name           Date       Change Description                              */
/* Ross Pulliam   29 JUN 21  File Creation                                   */
/* Ross Pulliam    7 JUL 21  Added Config File IO, Milestone Driver          */
/* Josh Sweeney    9 JUL 21  Function call to TileOrganiser                  */
/* Allyson Tesky  10 JUL 21  Function calls, vector conversion, analysis     */
/* Allyson Tesky  11 JUL 21  Area Specific Analysis                          */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

#include <string>
#include <iostream>
#include <fstream>
#include "config.h"
#include "region.h"
#include "TileOrganiser.h"
#include "totalpollution.h"
#include "pollution.h"
#include "population.h"

config *readConfig();
void area(vector<vector<Tile>>,vector<vector<int>>);

int main () {
	// Variable declaration
	config *settings = NULL;
	region initRegion;
	TileOrganiser citySimulation;
	vector<vector<char>> initCity;
	vector<vector<Tile>> city;
	vector<vector<int>> pollution;

	// Build settings object from config file
	settings = readConfig();
	if (settings == NULL) {
		std::cout << "Failed to read config file, exiting program.\n";
		return 0;
	}

	// build region object
	initRegion.Fileio(settings);

	// Gets, updates and prints the city
	initCity = initRegion.GetCity();
	city = citySimulation.TileOrganiserMain(initCity, settings->GetTimeLimit(), settings->GetRefreshRate());

	// Creates pollution data and prints pollution vector
	pollution = Pollution(city);

	// Final populations and pollution, max parameters used
	std::cout << "\nThe total populations for the region are: \n";
	population(city,0,0,initCity.size()-1,initCity[0].size()-1);
	std::cout << "The total pollution in the region is " << totalPollution(pollution,0,0,pollution.size()-1,pollution[0].size()-1) << " units\n";

	// area analysis
	area(city, pollution);

	// Clean up dynamic memory
	delete settings;

	return 0;
}

// Author: 		Ross Pulliam
// Function: 	config *readConfig()
// Return:		Bad config filename: NULL
//					Valid config filename: config object
// Purpose: 	To prompt user for config file (and path if needed), parse for valid filename,
// 				build the config object

config *readConfig() {
	// Function variables
	std::string confFile, regFile, tlimitStr, rrateStr, debFile, tStamp;
	int tlimit, rrate;
	config *s = NULL;
	bool invalid = false;
	std::size_t found;

	// Prompt user for config file path+name
	std::cout << "If the configuration file is located outside the program directory, please include the full path.\n";
	std::cout << "What is the name of the config file (filename.txt)? ";
	getline(std::cin, confFile);
	std::cout << std::endl;

	// Validate config file meets requirements (filename.txt)
	while (!invalid) {
		found = confFile.find(".");
		if (found==std::string::npos || confFile.substr(found) != ".txt") {
			std::cout << "File must end in .txt. Please try again or q to quit:";
			getline(std::cin, confFile);
		}
		else
			invalid = true;
		if (confFile == "q")
			return NULL;
	}

	// Prep file in stream
	std::ifstream file;
	file.open(confFile);
	if (file.is_open()) {

		// Read region file name, parse the file name from the config file line (data after :)
		getline(file, regFile);
		// Validate region csv file
		found = regFile.find(".");
		if (found==std::string::npos || regFile.substr(found)!=".csv") {
			std::cout << "Invalid region file type, please use .csv files to describe the region\n";
			return NULL;
		}
		found = regFile.find(":");
		regFile = regFile.substr(found+1);

		// Read time limit, parse int from end of string, convert to int (data after :)
		std::getline(file, tlimitStr);
		found = tlimitStr.find(":");
		tlimitStr = tlimitStr.substr(found+1);
		try {
			tlimit = std::stoi(tlimitStr);
		} catch (const std::exception& e) {
			std::cout << "Exception, check " << confFile << " time limit integer value.\nExpected format: \"Time Limit:XX\"\n";
			return NULL;
		}

		// Read refresh rate, parse int from end of string, convert to int (data after :)
		std::getline(file, rrateStr);
		found = rrateStr.find(":");
		rrateStr = rrateStr.substr(found+1);
		try {
			rrate = std::stoi(rrateStr);
		} catch (const std::exception& e) {
			std::cout << "Exception, check " << confFile << " refresh rate integer value.\nExpected format: \"Refresh Rate:XX\"\n";
			return NULL;
		}

		// Build config object
		s = new config(confFile, regFile, tlimit, rrate);

	}
	else
		std::cout << "Failed to open " << confFile << " to read.\n";

	return s;
}

// Author: 		Allyson Tesky
// Function: 	void area(vector<vector<Tile>> city, vector<vector<int>> pollution)
// Return:		none
// Purpose:  	Provide a population and pollution detail on any user defined rectangular
//					grid. This function handles both user input, validation, and display of
//					requested data.	

void area(vector<vector<Tile>> city,vector<vector<int>> pollution){
	// Variable declaration
	int X1, X2, Y1, Y2, temp;

	// Prompt user for corners of grid, negative number to skip
	cout << "Please enter the diagonal corners of the area you wish to have more information about.\n" <<
	"  (MinX = 0, MinY = 0, MaxX = " << city[0].size()-1 << ", MaxY = " << city.size()-1 << ")\n";
	cout << "  (enter a negative number to skip.\n";

	// User input and validation for X1 of the grid
	bool valid = false;
	do{
		cout << "X1: "; cin >> X1;
		if(cin.good()){
			if(X1>=0&&X1<city[0].size()){
				valid = true;
			}
			else
				if (X1 < 0)
					return;
			else{
				cout << "Out of Range\n";
				cin.ignore();
			}
		}
		else{
			cout << "invalid input\n";
			cin.clear();
			cin.ignore();
		}
	}while(!valid);

	// User input and validation for Y2 of the grid
	valid = false;
	do{
		cout << "Y1: "; cin >> Y1;
		if(cin.good()){
			if(Y1>=0&&Y1<city.size()){
				valid = true;
			}
			else
				if (Y1 < 0)
					return;
			else{
				cout << "Out of Range\n";
				cin.ignore();
			}
		}
		else{
			cout << "invalid input\n";
			cin.clear();
			cin.ignore();
		}
	}while(!valid);

	// User input and validation for X2 of the grid
	valid = false;
	do{
		cout << "X2: "; cin >> X2;
		if(cin.good()){
			if(X2>=0&&X2<city[0].size()){
				valid = true;
			}
			else
				if (X2 < 0)
					return;
			else{
				cout << "Out of Range\n";
				cin.ignore();
			}
		}
		else{
			cout << "invalid input\n";
			cin.clear();
			cin.ignore();
		}
	}while(!valid);

	// User input and validation for Y2 of the grid
	valid = false;
	do{
		cout << "Y2: "; cin >> Y2;
		if(cin.good()){
			if(Y2>=0&&Y2<city.size()){
				valid = true;
			}
			else
				if (Y2 < 0)
					return;
			else{
				cout << "Out of Range\n";
				cin.ignore();
			}
		}
		else{
			cout << "invalid input\n";
			cin.clear();
			cin.ignore();
		}
	}while(!valid);

	// Allows user to set any X and Y corners
	if(X1>X2){
		temp = X1;
		X1 = X2;
		X2 = temp;
	}
	if(Y1>Y2){
		temp = Y1;
		Y1 = Y2;
		Y2 = temp;
	}

	// Display total population and pollution of the requested grid
	std::cout << "The total populations for the requested area are: \n";
	population(city,Y1,X1,Y2,X2);
	std::cout << "The total pollution in the requested area is " << totalPollution(pollution,Y1,X1,Y2,X2) << " units\n";

}
