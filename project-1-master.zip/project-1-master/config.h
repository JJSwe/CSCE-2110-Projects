

#ifndef CONFIG_H
#define CONFIG_H

#include <string>

class config {
	public:
		// Default constructor
		config();

		// Paramaterized constructor
		config(std::string cf, std::string rf, int t, int r);

		// Setters
		void SetConfigFile(std::string cf);
		void SetRegionFile(std::string rf);
		void SetTimeLimit(int t);
		void SetRefreshRate(int r);

		// Getters
		std::string GetConfigFile();
		std::string GetRegionFile();
		int GetTimeLimit();
		int GetRefreshRate();

	private:
		std::string configFile;
		std::string regionFile;
		int timeLimit;
		int refreshRate;
};


#endif
