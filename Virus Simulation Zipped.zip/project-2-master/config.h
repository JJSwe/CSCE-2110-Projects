


#ifndef CONFIG_H
#define CONFIG_H

#include <string>

class config {
	public:
		// Default constructor
		config();

		// Parameterized constructor
		config(std::string pf, std::string rf, int iA, int iP, int cR, int vC);

		// Setters
		void SetPopFile(std::string pf);
		void SetRegFile(std::string rf);
		void SetInfectArea(int iA);
		void SetInfectPeriod(int iP);
		void SetContactRate(int cR);
		void SetVaxCnt(int vC);

		// Getters
		std::string GetPopFile();
		std::string GetRegFile();
		int GetInfectArea();
		int GetInfectPeriod();
		int GetContactRate();
		int GetVaxCnt();

		// Utilities


	private:
		std::string popFile;
		std::string regFile;
		int infectArea;
		int infectPeriod;
		int contactRate;
		int vaxCnt;
};

#endif
