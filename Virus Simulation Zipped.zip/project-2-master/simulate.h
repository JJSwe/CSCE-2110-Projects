#ifndef SIMULATE_H
#define SIMULATE_H
#include <string>
#include "city.h"

struct finalData{
	 std::string dist;
    int peak = 0;
    int peakDay = 0;
    int finalDay = 0;
	 int totalInfected = 0;
	 bool updated = false;
};

class Simulate{
private:
    std::vector<city> region;
    int day = 0;
    int rate = 0;
    int period = 0;
    finalData data;
    std::vector<int> infectedArea;
public:
    Simulate(){day = 0; rate = 0; period = 0;}
    void simulate(int, int, int,vector<city>); // Rate, Period, First Infected City, and populated cities
    void step();
    void run();
    void print();
    finalData getData();
};

#endif
