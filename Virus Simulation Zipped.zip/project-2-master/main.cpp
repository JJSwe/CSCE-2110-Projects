/*****************************************************************************/
/* File: main.cpp                                                            */
/* Authors: Allyson Tesky, Josh Sweeney, Ross Pulliam                        */
/* Creation date: 16 JUL 2021                                                */
/*****************************************************************************/
/* Revisions                                                                 */
/* Name           Date       Change Description                              */
/* Ross Pulliam   16 JUL 21  File creation                                   */
/* Ross Pulliam   24 JUL 21  Modify Menu, Add city object, Reconfigure main  */
/* Allyson Tesky  25 JUL 21  Added function calls to menu for simulation     */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <iomanip>
#include "config.h"
#include "data.h"
#include "distribution.h"
#include "city.h"
#include "simulate.h"
using namespace std;

#define SIMS 4

int printMenu(std::string s);
std::string promptConfFile();
config *getConfig(std::string confFile);

int main () {

	// Variable declaration
	int selection = 1;
	std::string confFile;
	config *confObj = NULL;
	data dataObj;
	std::vector<city> cities;
	Distribution distribution;
	finalData closeData, degData, ranData, equData; // Struct with data.peak, data.peakDay, and data.finalDay
	Simulate simulation;
	// There are 4 simulations creating data [0]:close, [1]:deg, [2]:ran, [3]:equ
	finalData results[SIMS] = { {"Closeness Distribution"},{ "Degree Distribution"},{"Random Distribution"},{"Equal Distribution"} };

	// Print menu	
	std::cout << " CSCE 2110 Summer '21\nProject 2: Contagion Simulation\n\n";
  
	// Program loop
	while (selection > 0 && selection < 10) {
		selection = printMenu(confFile);
		switch (selection) {
			case 1:	{ // Load config
						confFile = promptConfFile();
						if (confFile != "") {
							confObj = getConfig(confFile);
							if (confObj != NULL) {
								cities.clear();
								for (int i = 0; i < SIMS; i++)
									results[i].updated = false;
								dataObj.ReadAreaPops(confObj, &cities);
								dataObj.PrintPop(&cities);
								dataObj.ReadAdjArr(confObj, &cities);
								dataObj.PrintAdjArr(&cities);
							}
							else
								confFile = "";
						}
				break;
				}
			case 2:	// Closeness Dist
				distribution.ClosenessDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[0] = simulation.getData();
				results[0].updated = true;
				results[0].dist = "Closeness Distribution";
				dataObj.PrintResults(&results[0]);
				break;
			case 3:	// Degree Dist
				distribution.DegreeDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[1] = simulation.getData();
				results[1].updated = true;
				results[1].dist = "Degree Distribution";
				dataObj.PrintResults(&results[1]);
				break;
			case 4:	// Random Dist
				distribution.RandomDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[2] = simulation.getData();
				results[2].updated = true;
				results[2].dist = "Random Distribution";
				dataObj.PrintResults(&results[2]);
				break;
			case 5:	// Equal Dist
				distribution.EqualDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[3] = simulation.getData();
				results[3].updated = true;
				results[3].dist = "Equal Distribution";
				dataObj.PrintResults(&results[3]);
				break;
			case 6:	// View Population
					dataObj.PrintPop(&cities);
				break;
			case 7:	// View Adjacency
					dataObj.PrintAdjArr(&cities);
				break;
			case 8:	// Run All Sims
				// Run Closeness Sim
				distribution.ClosenessDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[0] = simulation.getData();
				results[0].updated = true;
				results[0].dist = "Closeness Distribution";
				// Run Degree Sim
				distribution.DegreeDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[1] = simulation.getData();
				results[1].updated = true;
				results[1].dist = "Degree Distribution";
				// Run Random Sim
				distribution.RandomDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[2] = simulation.getData();
				results[2].updated = true;
				results[2].dist = "Random Distribution";
				// Run Equal Sim
				distribution.EqualDistribution(cities, confObj->GetVaxCnt());
				simulation.simulate(confObj->GetContactRate(),confObj->GetInfectPeriod(),confObj->GetInfectArea(),cities);
				simulation.run();
				results[3] = simulation.getData();
				results[3].updated = true;
				results[3].dist = "Equal Distribution";
				break;
			case 9:	// Display Results
				std::cout << "DISPLAY ALL RESULTS\n\n";
				for (int i = 0; i < SIMS; i++)
					dataObj.PrintResults(&results[i]);
				std::cout << std::endl;
				break;
			case 10:	// Quit
					return 0;
				break;
		}
	}
	
	delete confObj;

	return 0;
}

/*****************************************************************************/
// Function:    printMenu
// Parameters:  string s
// Return: int
// Description: This function prints the user menu and prompts for user
//              selection. The function also validates that input before
//              returning the integer value menu selection.

int printMenu(std::string s) {
	// Variable declaration
	int select = -1;
	std::string input;
	bool valid = false;

	// Print menu
	std::cout << "Main Menu - Contagion Simulation\n\n";
	std::cout << "  1. Load new configuration file (current file: ";
	if (s == "")
		std::cout  << "none)" << std::endl;
	else
		std::cout << s << ")\n";
	if (s != "") {
		std::cout << "  2. Closeness Distribution\n";
		std::cout << "  3. Degree Distribution\n";
		std::cout << "  4. Random Distribution\n";
		std::cout << "  5. Equal Distribution\n";
		std::cout << "  6. View Regonal Population\n";
		std::cout << "  7. View Adjacenty List\n";
		std::cout << "  8. Run all simulations\n";
		std::cout << "  9. Display Simulation results\n";
	}
	std::cout << " 10. Quit\n";
	std::cout << std::endl;
	std::cout << "Enter number selection: ";

	// Read and validate
	while (!valid) {
		getline(std::cin, input);
		try {
			select = std::stoi(input);
			valid = true;
		} catch (const std::exception& e) {
			std::cout << "Invalid input, please try again: ";
		}
		if (s == "") {
			if ((select != 1) && (select != 10)) {
				valid = false;
				std::cout << "Invalid selection, please choose option 1 or 10: ";
			}
		}
		else if (select < 1 || select > 10) {
			valid = false;
			std::cout << "Invalid selection, please select an option between 1 and 10: ";
		}
	}

	std::cout << std::endl;

	return select;
}
/************** End printMenu ************************************************/

/*****************************************************************************/
// Function:    promptConfFile
// Parameters:  none
// Returns:     string fileName 
// Description: 
std::string promptConfFile() {
	// Variabble declaration
	std::string filename;
	bool valid = false;
	std::size_t found;

	// Prompt for filename
	std::cout << "If the configuration file is located outside of the program directory,\n";
	std::cout << "please include the full path.\n";
	std::cout << "What is the name of the config file (filename.txt)? ";

	while (!valid) {
		getline(std::cin, filename);
		if (filename == "r") {
			std::cout << std::endl;
			return "";
		}
		found = filename.find(".");
		if (found ==std::string::npos || filename.substr(found) != ".txt")
			std::cout << "File must end in .txt. Please try again or r to return: ";
		else
			valid = true;
	}
	std::cout << std::endl;

	return filename;
}
/************* end promptConfFile ********************************************/

/*****************************************************************************/
// Function:    *getConfig
// Parameters:  string
// Returns:     config object pointer
// Description: 

config *getConfig(std::string confFile) {
	// Variable declaration
	std::string pf, rf, intStr;
	int ia, ip, cr, vc;
	std::ifstream file;
	std::size_t found;
	config *c;

	// IFStream
	file.open(confFile);
	if (file.is_open()) {
		// Read and validate population file
		getline(file, pf);
		found = pf.find(".");
		if (found == std::string::npos || pf.substr(found)!=".txt") {
			std::cout << "Invalid population file extension, please use .txt files to define population.\n";
			return NULL;
		}
		found = pf.find(":");
		pf = pf.substr(found+1);

		// Read and validate region file
		getline(file, rf);
		found = rf.find(".");
		if (found==std::string::npos || rf.substr(found)!=".csv") {
			std::cout << "Invalid region file extension, please use .csv files to describe the region.\n";
			return NULL;
		}
		found = rf.find(":");
		rf = rf.substr(found+1);

		// Throw away blank line in file
		getline(file, intStr);

		// Read and validate infected area
		getline(file, intStr);
		found = intStr.find(":");
		intStr = intStr.substr(found+1);
		try {
			ia = std::stoi(intStr);
		} catch (const std::exception& e) {
			std::cout << "Exception, check " << confFile << " Infected Area integer value.\n";
			std::cout << "Expected format:\nInfected Area:XX\n";
			return NULL;
		}

		// Read and validate Infection period
		getline(file, intStr);
		found = intStr.find(":");
		intStr = intStr.substr(found+1);
		try {
			ip = std::stoi(intStr);
		} catch (const std::exception& e) {
			std::cout << "Exception, check " << confFile << " Infectious Period integer value.\n";
			std::cout << "Expected format:\nInfectious Period:XX\n";
			return NULL;
		}

		// Read and validate Contact Rate
		getline(file, intStr);
		found = intStr.find(":");
		intStr = intStr.substr(found+1);
		try {
			cr = std::stoi(intStr);
		} catch(std::exception& e) {
			std::cout << "Exception, check " << confFile << " Contact Rate integer value.\n";
			std::cout << "Expected format:\nContact Rate:XX\n";
			return NULL;
		}

		// Read and validate Number of Vaccines
		getline(file, intStr);
		found = intStr.find(":");
		intStr = intStr.substr(found+1);
		try {
			vc = std::stoi(intStr);
		} catch(std::exception& e) {
			std::cout << "Exception, check " << confFile << " Number of Vaccines integer value.\n";
			std::cout << "Expected format:\nNumber of Vaccines:XXXXX\n";
			return NULL;
		}
	}
	else {
		std::cout << "Failed to open " << confFile << " to read.\n\n";
		return NULL;
	}

	// Close file
	file.close();

	// Build config object
	c = new config(pf, rf, ia, ip, cr, vc);

	return c;
}
/********************** end *getConfig() *************************************/

