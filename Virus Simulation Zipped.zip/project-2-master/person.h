#ifndef PERSON_H
#define PERSON_H
#include <iostream>
using namespace std;

class Person{
    private:
    char status = 'S';
    int infection = -1;
    public:
    char getStatus(){
        return status;
    }
    void setStatus(char status){
        this->status=status;
    }
    int getInfection(){
        return infection;
    }
    void setInfection(int infection){
        this->infection=infection;
    }
};

#endif
