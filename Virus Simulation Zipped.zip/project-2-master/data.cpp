
#include "config.h"
#include "data.h"
#include "city.h"

// constructor
data::data() { };

// Utilities
void data::ReadAreaPops(config *c, std::vector<city> *ci) {
	// Variable declaration
	std::ifstream file;
	std::string line;
	int pop;
	std::size_t found;
	int cityNum = 1;
	city *newCity;
	
	// Open file and begin reading, push back int to vector<int> areaPops
	file.open(c->GetPopFile());
	getline(file, line);
	while (!file.eof()) {
		found = line.find(":");
		line = line.substr(found+1);
		// convert string int to integer, catch exception if file input is noninteger
		try {
			pop = std::stoi(line);
		} catch(const std::exception& e) {
			std::cout << "Exception, check " << c->GetPopFile() << " for errors. Each line ";
			std::cout << "should follow the format AREA:POPULATION.\n";
			return;
		}
		newCity = new city(cityNum, pop);
		ci->push_back(*newCity);
		cityNum++;
		getline(file, line);
	}
};

void data::ReadAdjArr(config *c, std::vector<city> *ci) {
	// Variable declaration
	std::ifstream file;
	std::string line;
	int n = ci->size() + 1;
	std::size_t found;
	int areaNum = 1;
	int addAdjArea;

	// Read the data and City object adjacencies
	file.open(c->GetRegFile());
	if (file.is_open()) {
		getline(file, line); // Throw away the first line
		getline(file, line);
		while(!file.eof()) {
			addAdjArea = 0;
			found = line.find(","); // find the first comma
			line.erase(0,found); // strip the leading integer from the line
			for (int i = 1; i < n*2; i++) {
				if (i%2 == 1)
					addAdjArea++;
				if (line[i] != ',' && line[i] == '1')
					ci->at(areaNum-1).AddAdjacency(addAdjArea);
			}
			getline(file, line);
			areaNum++;
		}
	}		
	else
		std::cout << "Failed to open region definition file: " << c->GetRegFile() << std::endl;

};

void data::PrintPop(std::vector<city> *ci) {
	int i = 1;
	std::cout << "Regional Population\n";
	for (auto it = ci->begin(); it != ci->end(); it++)
		std::cout << it->GetAreaNum()  << " " << it->GetPopulation() << std::endl;
	std::cout << std::endl;
};

void data::PrintAdjArr(std::vector<city> *ci) {
	std::cout << "Adjacency List\n";
	for (auto it = ci->begin(); it != ci->end(); it++) {
		it->PrintAdjacencies();
	}
	std::cout << std::endl;
};

void data::PrintResults(finalData *r) {
	if (r->updated) {
		std::cout << "Using the " << r->dist << " method, the peak number of infected was \n";
		std::cout  << r->peak << " on day " << r->peakDay << ". The outbreak ended on day ";
		std::cout << r->finalDay << " and the total number of\ninfected individuals was ";
		std::cout  << r->totalInfected << "." << "\n\n";
	}
	else
		std::cout << r->dist << " has not been ran.\n";
};
