
#include "config.h"

// Default constructor
config::config() { popFile = ""; regFile == ""; infectArea = -1; infectPeriod = -1;
						 contactRate = -1; vaxCnt = -1; };

// Parameterized constructor
config::config(std::string pf, std::string rf, int iA, int iP, int cR, int vC) {
	popFile = pf;
	regFile = rf;
	infectArea = iA;
	infectPeriod = iP;
	contactRate = cR;
	vaxCnt = vC; };

// Setters
void config::SetPopFile(std::string pf) { popFile = pf; };
void config::SetRegFile(std::string rf) { regFile = rf; };
void config::SetInfectArea(int iA) { infectArea = iA; };
void config::SetInfectPeriod(int iP) { infectPeriod = iP; };
void config::SetContactRate(int cR) { contactRate = cR; };
void config::SetVaxCnt(int vC) { vaxCnt = vC; };

// Getters
std::string config::GetPopFile() { return popFile; };
std::string config::GetRegFile() { return regFile; };
int config::GetInfectArea() { return infectArea; };
int config::GetInfectPeriod() { return infectPeriod; };
int config::GetContactRate() { return contactRate; };
int config::GetVaxCnt() { return vaxCnt; };

// Utilities
