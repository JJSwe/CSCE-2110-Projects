#ifndef CITY_H
#define CITY_H

#include <vector>
#include <iostream>
#include "person.h"


class city{
	private:
		int areaNumber; // identity
		int population;
		vector<int> adjacencies;
		int vaccines; 
		int recovered;
		int susceptible;
		int infected;
		bool safe;
		vector<Person> pop;
	public:
		// Constructor
		city();
		city(int an, int p);
		city(int an, int p, vector<int> a);

		// Setters
		void SetAreaNum(int a);
		void SetPopulation(int p);
		void SetAdjacencies(vector<int> a);
		void SetVaccines(int vaccines);
		void SetRecovered(int r);
		void SetInfected(int i);
		void SetSusceptible(int s);

		// Getters
		int GetAreaNum();
		int GetPopulation();
		vector<int> GetAdjacencies();
		int GetVaccines();
		int GetRecovered();
		int GetInfected();
		int GetSusceptible();
		bool isProtected();

		// Utilities
		void AddAdjacency(int newAdj);
		void PrintAdjacencies();

		// Simulation
		void Prepare(bool);
		void Infect(int);
		void Recover(int);
		void Update(); // If City is Newly infected
		bool Spread();


};

#endif
