#include "distribution.h"
#include "city.h"

bool testing = false;

// Sets all vaccines to 0 when a new distribution is made.
void Distribution::ClearVaccines(vector<city>& cities) {
    for(auto& city : cities) {
        city.SetVaccines(0);
    }
}

// Gives vaccines to the area with the largest value in vaccineOrder.
void Distribution::DistributeVaccinesInOrder(vector<city>& cities, vector<int> vaccineOrder, int vaccineCount) {
    ClearVaccines(cities);
    int size = cities.size();
    vector<int> areaPopulation;
    for(auto city : cities) {
        areaPopulation.push_back(city.GetPopulation());
    }
    int area = 0;
    for(int loop = 0; loop < size; loop++) {
        // Loop to find the next area to be vaccinated.
        for(int nextArea = 1; nextArea < size; nextArea++) {
            if(vaccineOrder.at(nextArea) > vaccineOrder.at(area)) {
                area = nextArea;
            }
        }
        // Sets the amount of vaccine to be used.
        int vaccineUsed = areaPopulation.at(area);
        if(vaccineUsed > vaccineCount) {
            vaccineUsed = vaccineCount;
        }
        cities[area].SetVaccines(vaccineUsed);
        // Updates amount of vaccine left, stops if no more vaccine.
        vaccineCount -= vaccineUsed;
        if(vaccineCount <= 0) {
            break;
        }
        vaccineOrder.at(area) = -1;
        area = 0;
    }
    // For Testing
    if(testing) {
        for(auto city : cities) {
            cout << city.GetVaccines() << endl;
        }
    }
}

// Gives vaccines to areas that have the average shortest distance to all areas.
void Distribution::ClosenessDistribution(vector<city>& cities, int vaccineCount) {
    int size = cities.size();
    vector<int> farthestDistanceCount;
    for(int area = 1; area <= size; area++) {
        vector<int> toCheck;
        vector<int> isChecking = {area};
        vector<int> hasChecked;
        int areasChecked = 1;
        int distanceAverage = 0;
        int distancetoArea = size;
        while (areasChecked < size) { // Stops when all zones have been checked.
            hasChecked.push_back(isChecking.front());
            vector<int> connections = cities[isChecking.front() - 1].GetAdjacencies();
            for(int newArea : connections) { // Finds if zone is new.
                bool isNew = true;
                for(int oldArea : hasChecked) {
                    if(newArea == oldArea) {
                        isNew = false;
                    }
                }
                if(isNew) { // If new, add to distanceAverage
                    distanceAverage += distancetoArea;
                    areasChecked++;
                    toCheck.push_back(newArea);
                    hasChecked.push_back(newArea);
                }
            }
            isChecking.erase(isChecking.begin());
            if(isChecking.empty()) { // uses the farther away areas once close areas are gone.
                distancetoArea--;
                isChecking = toCheck;
                toCheck.clear();
            }
        }
        farthestDistanceCount.push_back(distanceAverage);
    }
    DistributeVaccinesInOrder(cities, farthestDistanceCount, vaccineCount);
}

// Gives vaccines to areas with highest amount of adjacent areas.
void Distribution::DegreeDistribution(vector<city>& cities, int vaccineCount) {
    vector<int> adjacentAreasCount;
    for(auto city : cities) {
        adjacentAreasCount.push_back(city.GetAdjacencies().size());
    }
    DistributeVaccinesInOrder(cities, adjacentAreasCount, vaccineCount);
}

//Gives vaccines to first area, then second, etc.
void Distribution::RandomDistribution(vector<city>& cities, int vaccineCount) {
    int size = cities.size();
    vector<int> randomDistribution;
    for(int pos = 0; pos < size; pos++) {
        randomDistribution.push_back(size - pos);
    }
    DistributeVaccinesInOrder(cities, randomDistribution, vaccineCount);
}

//Equally distributes all vaccines. Redistributes when an area has extra vaccine.
void Distribution::EqualDistribution(vector<city>& cities, int vaccineCount) {
    ClearVaccines(cities); // Is only necessary if an area has a pop of 0.
    int size = cities.size();
    vector<int> areaPopulation;
    for(auto city : cities) {
        areaPopulation.push_back(city.GetPopulation());
    }
    vector<int> areaVaccines(size, 0);
    vector<int> fullArea;
    int vaccineDivided = vaccineCount / size;
    int vaccineLeftovers = vaccineCount % size;
    // Gives each area their portion of vaccine, repeats if an area can't use all of its vaccine.
    while (vaccineDivided > 0) {
        for(int loop = 0; loop < size; loop++) {
            // Skips areas that are full.
            bool isFull = false;
            for(int area : fullArea) {
                if(loop == area) {
                    isFull = true;
                    break;
                }
            }
            if(isFull) {
                continue;
            }
            // Figures out amount of vaccine to use & records areas that are now full.
            int vaccineUsed = vaccineDivided;
            int vaccinesNeeded = areaPopulation.at(loop) - areaVaccines.at(loop);
            if(vaccineUsed > vaccinesNeeded) {
                vaccineUsed = vaccinesNeeded;
                fullArea.push_back(loop);
            }
            areaVaccines.at(loop) += vaccineUsed;
            vaccineCount -= vaccineUsed;
        }
        // Figures out if more vaccines need to be divided up.
        vaccineDivided = vaccineCount / (size - fullArea.size());
        vaccineLeftovers = vaccineCount % (size - fullArea.size());
    }    
    // Adds the last few vaccines.
    for(int loop = 0; loop < vaccineLeftovers; loop++) {
        bool isFull = false;
        for(int area : fullArea) {// Skips areas that are full
            if(loop == area) {
                vaccineLeftovers++;
                isFull = true;
                break;
            }
        }
        if(!isFull) {
            areaVaccines.at(loop)++;
        }
    }
    // Gives vaccines directly to city class.
    for(int pos = 0; pos < cities.size(); pos++) {
        cities[pos].SetVaccines(areaVaccines.at(pos));
    }
    // For Testing
    if(testing) {
        for(auto city : cities) {
            cout << city.GetVaccines() << endl;
        }
    }
}
