#include "city.h"

// Constructors
city::city() { areaNumber = 0; population = 0; adjacencies.clear(); vaccines = 0; }
city::city(int an, int p) { areaNumber = an; population = p; adjacencies.clear(); vaccines = 0; recovered = 0; susceptible = 0; safe = false; infected = 0; pop = vector<Person>(population);}
city::city(int an, int p, std::vector<int> a) { areaNumber = an; population = p; adjacencies = a; vaccines = 0; recovered = 0; susceptible = population-vaccines; safe = false; infected = 0; pop = vector<Person>(population);}

// Setters
void city::SetAreaNum(int a) { areaNumber = a; }
void city::SetPopulation(int p) { population = p; }
void city::SetAdjacencies(std::vector<int> a) { adjacencies = a; }
void city::SetVaccines(int vaccines) { this->vaccines = vaccines; }
void city::SetRecovered(int r) { recovered = r; }
void city::SetInfected(int i){ infected = i; }
void city::SetSusceptible(int s){ susceptible = s; }

// Getters 
int city::GetAreaNum() { return areaNumber; }
int city::GetPopulation() { return population; }
std::vector<int> city::GetAdjacencies() { return adjacencies; }
int city::GetVaccines() { return vaccines; }
int city::GetRecovered(){ return recovered; }
int city::GetInfected(){ return infected; }
int city::GetSusceptible(){ return susceptible; }
bool city::isProtected(){ return safe; }

// Utilities
void city::AddAdjacency(int newAdj) { adjacencies.push_back(newAdj); };

void city::PrintAdjacencies() {
	std::cout << areaNumber << ": ";
	for (auto it = adjacencies.begin(); it != adjacencies.end(); it++)
		std::cout << *it << " ";
	std::cout << std::endl;
}

// Simulation
void city::Prepare(bool infected){
	int vax = vaccines;
	if (vaccines==population){
		safe = true;
		for(int i = pop.size()-1; i >= 0; i--){
			pop[i].setStatus('V'); // Vaccinates whole city
		}
		} // Prevents fully vaccinated cities from getting infected
	else{
		if(vaccines!=0){
			for(int i = pop.size()-1; i >= 0; i--){ // vaccinates at end of list
				pop[i].setStatus('V');
				vax--;
				if(vax==0){ break; }
			}
		}
	susceptible = population - vaccines; 
	if(infected){ // passed from simulate
		pop[0].setStatus('I'); // Patient 0
		pop[0].setInfection(1); // Day 0
		this->infected += 1;
		susceptible-=1;
	}
	}
}
void city::Infect(int contact){
	int victims = contact*infected;

	for(int i = 0; i < pop.size(); i++){
		if (susceptible > 0 && victims > 0){
			if(pop[i].getStatus()=='S'){
				susceptible-=1; victims-=1; infected+=1;
				pop[i].setStatus('I');
				pop[i].setInfection(0);
			} 
		}
		else {break;}
	}
}
void city::Recover(int period){

	for(int i = 0; i < pop.size(); i++){
		if(pop[i].getStatus()=='I'&&pop[i].getInfection()==period){
			pop[i].setStatus('R');
			recovered+=1;
			infected-=1;
		}
		if(pop[i].getStatus()=='I'){ // Updates length of infection after recoveries
			pop[i].setInfection((pop[i].getInfection()+1));
		}
	}
}
void city::Update(){// Called in lieu of recover/infect
	if(pop[0].getStatus()=='S'){
		pop[0].setStatus('I');
		pop[0].setInfection(1); // Doesn't update on first day
		infected+=1;
		susceptible-=1;
	}
} // If City is Newly infected

bool city::Spread(){
	bool spread = false; // Whether or not the infection can spread cities
	if(infected>(population/2)){
		spread = true;
		}
	return spread;
}
