#ifndef DISTRIBUTION_H
#define DISTRIBUTION_H

#include <iostream>
#include <vector>
#include <array>
#include "data.h"
using namespace std;

class Distribution {
    public:
        void ClearVaccines(vector<city>& cities);
        void DistributeVaccinesInOrder(vector<city>& cities, vector<int> vaccineOrder, int vaccineCount);
        void ClosenessDistribution(vector<city>& cities, int vaccineCount);
        void DegreeDistribution(vector<city>& cities, int vaccineCount);
        void RandomDistribution(vector<city>& cities, int vaccineCount);
        void EqualDistribution(vector<city>& cities, int vaccineCount);
};

#endif
