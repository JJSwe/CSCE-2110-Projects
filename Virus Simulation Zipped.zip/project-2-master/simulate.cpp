#include "simulate.h"

void Simulate::simulate(int rate, int period, int infected,vector<city> cities){
this->rate = rate; this->period = period; region = cities; day = 0;
infectedArea = vector<int>(cities.size(),0);
infectedArea[infected-1]=1; // Indexed at areaNumber-1
} // Rate, Period, First Infected City, and populated cities

void Simulate::step(){
bool spread = false;
int totalInfected = 0;

for(int i = 0; i < infectedArea.size(); i ++){
    spread = region[i].Spread();
    if(spread){ // spreads infection to adjacent and unprotected cities
        for(int j = 0; j<(region[i].GetAdjacencies()).size();j++){
            if(!(region[(region[i].GetAdjacencies())[j]-1].isProtected())&&(region[(region[i].GetAdjacencies())[j]-1].GetSusceptible()>0)){
                infectedArea[(region[i].GetAdjacencies())[j]-1] = 1;
            }
        }
    }
    spread = false;
}

for(int i = 0; i < infectedArea.size(); i++){
    if(infectedArea[i]==1){
        if(region[i].GetInfected()==0&&region[i].GetSusceptible()>0){
            region[i].Update(); // Creates patient 0
        }
        else{
            region[i].Infect(rate);
            region[i].Recover(period);
        }
        if(region[i].GetInfected()==0&&region[i].GetSusceptible()==0){
            infectedArea[i] = 0; // Sets city back to default / no longer infected
        }
    totalInfected+=region[i].GetInfected();
    spread = false;
    }
    if (totalInfected > data.peak){ // Populates peak data struct
        data.peak = totalInfected;
        data.peakDay = day+1;
    }
}
}
void Simulate::run(){
    data.totalInfected = 0; data.peakDay = 0; data.peak = 0; // Data reset to 0
    bool infected;
    bool day0;

    for(int i = 0; i<region.size();i++){
        if(infectedArea[i]==1) {
            region[i].Prepare(true);
            day0 = region[i].isProtected();
            }
        else{region[i].Prepare(false);}
    }
    if(!day0){
        do{ infected = false;
            print();
            step();
            for(int i = 0; i<region.size(); i++){ // Continues if a city is still infected
                if(infectedArea[i] == 1){
                    infected = true;
                }
            }
            day+=1;
            data.finalDay = day; // Updates daily
        }while(infected==true);
    }
    else{
        data.finalDay = 0; data.totalInfected = 0; data.peakDay = 0; data.peak = 0;
    }
    print();
	cout << endl;
    for(int i = 0; i<region.size(); i++){
        data.totalInfected += region[i].GetRecovered();
    }
}
void Simulate::print(){
    cout << "Day " << day << endl;
    cout << "Region\tPopulation\tS\tI\tR\tV\n";
    for (int i = 0; i < region.size(); i++){
        cout << region[i].GetAreaNum() << "\t" << region[i].GetPopulation() << "\t \t" << region[i].GetSusceptible()
        << "\t" << region[i].GetInfected() << "\t" << region[i].GetRecovered() << "\t" << region[i].GetVaccines()
        << endl;
    }
}

finalData Simulate::getData(){
    return data;
}
