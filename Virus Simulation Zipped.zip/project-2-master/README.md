# Contagion
**Group 9: Allyson Tesky, Josh Sweeney, Ross Pulliam**

## Overview
This submission includes all needed files to meet all project 2 requirements. The application requires the user provide a configuration file. The file must contain the location of the population.txt (area population numbers) and region.csv (adjacency matrix) files along with the initially infected area, the infectious period, contact rate, and the number of vaccines to be introduced into the simulation.

The program will confirm the configuration and population files are in text format (.txt file extension) and the region file is a comma separated values file (.csv). If these requirements are not met the user will have opportunity to input the name of a valid file.

Assuming a proper configuration file is provided, the simulation will load and store the needed data and initialize the simulation. The menu will change and provide all possible options to execute against the file including the four simulation types, area populations, adjacencies, and available results. Sample files can be found in the [wiki](https://apollo.cse.unt.edu/rhp0048/project-2/-/wikis/Reading-and-Initializing-the-Application#data-structures-and-transformations).

### Building and running the application:
    Use the included makefile to manage the compilation and run functions
        make:       rebuild the application
        make debug: build the application with debug flags
        make clean: remove the compiled object and executable files
        make run:   execute the program

### Sample user input
    
> Menu will display and prompt for user option: load configuration file or quit

    Option 1: Load configuration file
        Program will prompt for and validate a filename has been entered in the proper format (config.txt)
    Option 10: Quit the program

> If a valid config file is entered, the program will reprint a new menu with options that apply to the initialized simulation. If any config object parameters are invalid errors will display to console indicating what parameter is invalid and return the user to the original menu selection to input a new configuration file or quit the program.

    Option 1: Load new configuration file
    Option 2: Closeness Simulation
    Option 3: Degree Simulation
    Option 4: Random Simulation
    Option 5: Equal Simulation
    Option 6: View regional populations
    Option 7: View Adjacencies
    Option 8: Run all simulations
    Option 9: Display simulation results
    Option 10: Quit

### Sample execution
```
./sim
CSCE 2110 Summer '21
Project 2: Contagion Simulation

Main Menu - Contagion Simulation

  1. Load new configuration file (current file: none)
 10. Quit

Enter number selection: 1

If the configuration file is located outside of the program directory,
please include the full path.
What is the name of the config file (filename.txt)? config1.txt

Regional Population
1 5000
2 6000
3 4000
4 10000
5 2000
6 5000
7 4000
8 8000
9 7000

Adjacency List
1: 2 4 5 
2: 1 3 4 5 6 
3: 2 5 6 
4: 1 2 5 7 8 
5: 1 2 3 4 6 7 8 9 
6: 2 3 5 8 9 
7: 4 5 8 
8: 4 5 6 7 9 
9: 5 6 8 

Main Menu - Contagion Simulation

  1. Load new configuration file (current file: config1.txt)
  2. Closeness Distribution
  3. Degree Distribution
  4. Random Distribution
  5. Equal Distribution
  6. View Regonal Population
  7. View Adjacenty List
  8. Run all simulations
  9. Display Simulation results
 10. Quit

Enter number selection: 8

/// Step data displayed during simulation omitted for brevity ///

Main Menu - Contagion Simulation

  1. Load new configuration file (current file: config1.txt)
  2. Closeness Distribution
  3. Degree Distribution
  4. Random Distribution
  5. Equal Distribution
  6. View Regonal Population
  7. View Adjacenty List
  8. Run all simulations
  9. Display Simulation results
 10. Quit

Enter number selection: 9

DISPLAY ALL RESULTS

Using the Closeness Distribution method, the peak number of infected was 
6748 on day 7. The outbreak ended on day 25 and the total number of
infected individuals was 16500.

Using the Degree Distribution method, the peak number of infected was 
6748 on day 7. The outbreak ended on day 25 and the total number of
infected individuals was 16500.

Using the Random Distribution method, the peak number of infected was 
13742 on day 14. The outbreak ended on day 24 and the total number of
infected individuals was 25500.

Using the Equal Distribution method, the peak number of infected was 
7619 on day 22. The outbreak ended on day 32 and the total number of
infected individuals was 24438.


Main Menu - Contagion Simulation

  1. Load new configuration file (current file: config1.txt)
  2. Closeness Distribution
  3. Degree Distribution
  4. Random Distribution
  5. Equal Distribution
  6. View Regonal Population
  7. View Adjacenty List
  8. Run all simulations
  9. Display Simulation results
 10. Quit

Enter number selection: 10
```
