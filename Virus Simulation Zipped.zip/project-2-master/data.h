
#ifndef DATA_H
#define DATA_H

#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include "config.h"
#include "city.h"
#include "simulate.h"

class data {
	public:
		// default constructor
		data();

		// Utilities
		void ReadAreaPops(config *c, std::vector<city> *ci);
		void ReadAdjArr(config *c, std::vector<city> *ci);
		void PrintPop(std::vector<city> *ci);
		void PrintAdjArr(std::vector<city> *ci);
		void PrintResults(finalData *r);

	private:
		std::vector<int> areaVaccines;

};

#endif
